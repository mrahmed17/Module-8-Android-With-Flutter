This is a simple android app created to demonstrate my knowledge in Android Studio.
-----------------------------------------------------------------------------------
Hiran P E
