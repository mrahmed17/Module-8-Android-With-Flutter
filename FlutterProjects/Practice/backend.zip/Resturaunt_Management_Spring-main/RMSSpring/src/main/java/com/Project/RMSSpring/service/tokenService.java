package com.Project.RMSSpring.service;

import org.springframework.stereotype.Service;

@Service
public class tokenService {
}
