package com.Project.RMSSpring.entity;


public enum Role {

    ADMIN,

    USER,

    WAITER
}
