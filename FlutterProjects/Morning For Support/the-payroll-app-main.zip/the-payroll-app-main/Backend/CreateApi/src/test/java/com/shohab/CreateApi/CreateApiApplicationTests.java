package com.shohab.CreateApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CreateApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
