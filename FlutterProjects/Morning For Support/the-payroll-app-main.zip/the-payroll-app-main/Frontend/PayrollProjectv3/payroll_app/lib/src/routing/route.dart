class MyRoute{
  static String bonusRoute="/bonus";
  static String  advanceRoute="/advance";
  static String  leaveRoute="/leave";
  // static String  aRoute="/task";
  // static String  taskFormRoute="/task_form";
  // static String  timeActionRoute="/time_action";
}